package com.ashish.fileinputoutput.entity;

public class FileDTO {

	private String name;
	private String data;
	private String path;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
	public FileDTO(String name, String data, String path) {
		super();
		this.name = name;
		this.data = data;
		this.path = path;
	}
	public FileDTO() {
		
	}
	@Override
	public String toString() {
		return "FileDTO [name=" + name + ", data=" + data + ", path=" + path + "]";
	}
	
	

	
	
}
