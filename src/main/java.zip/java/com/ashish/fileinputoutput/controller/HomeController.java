
package com.ashish.fileinputoutput.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.ashish.fileinputoutput.BaseResponse;
import com.ashish.fileinputoutput.entity.FileDTO;

@RestController
@RequestMapping("/")
public class HomeController {


	private static Logger log = (Logger) LoggerFactory.getLogger(HomeController.class);
	private String[] file_names;

	private Map<String, String> filename_data = new HashMap<String, String>();
	private Map<String, Date> datetime = new HashMap<>();

	private DateFormat simple = new SimpleDateFormat("dd MMM yyyy HH:mm:ss:SSS Z");
	private Date result;

	// "C:\\Users\\Tri Tech\\Desktop\\FileFolder";
	// C://Users//user//Desktop//Documents//FileFolder
	@RequestMapping("/")
	public ModelAndView check() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("index");
		return mv;
	}

	// @RequestMapping("/dirPath/{path}")

	@RequestMapping("/getAllFiles")
	public BaseResponse getAllFiles(@RequestBody FileDTO dto) {
		
		BaseResponse response = new BaseResponse(true);
		log.info("getAllFiles api called");
		try {
			
			File file = new File(dto.getPath());
			file_names = file.list();
			log.info("Iteration method Called..");
			
			
			fileIteration(file_names,dto);

			response.addData(filename_data);
			response.addMessage("File are Successfully Fetched...");

		} catch (Exception e) {
			e.printStackTrace();
			response.addMessage(e.toString());
			response.setSuccess(false);
			return response;
		}
		return response;
	}

	@RequestMapping("/lastModiFiles")
	public BaseResponse lastModiFiles(@RequestBody FileDTO dto) {
		BaseResponse response = new BaseResponse(true);
		log.info("lastModiFiles api called");
		try {
			File file = new File(dto.getPath());
			file_names = file.list();

			File[] files = file.listFiles();
			Arrays.sort(files, new Comparator<File>() {

				@Override
				public int compare(File o1, File o2) {

					return Long.valueOf(o2.lastModified()).compareTo(o1.lastModified());
				}

			});

			int length = Math.min(files.length, 5);
			for (int i = 0; i < length; i++) {
				file_names[i] = files[i].getName();
				result = new Date(files[i].lastModified());
				datetime.put(file_names[i], result);
			}

			fileIteration(file_names,dto);

			response.addData(filename_data);
			response.addResult("datetime", datetime);
			response.addMessage("Last Modified Files are Successfully Fetched...");
		} catch (Exception e) {
			e.printStackTrace();
			response.addMessage(e.toString());
			response.setSuccess(false);
			return response;
		}
		return response;
	}

	@RequestMapping("/read")
	public BaseResponse read(@RequestBody FileDTO dto) {
		BaseResponse response = new BaseResponse(true);
		log.info("read api called");
		try {

			String data = getData(dto.getName(),dto);
			response.addResult(dto.getName(), data);
			response.addMessage("successfully fetch the data...");

		} catch (IOException e) {
			e.printStackTrace();
			response.addMessage(e.toString());
			response.setSuccess(false);
			return response;
		}
		return response;
	}

	@RequestMapping(value="/write")
	public BaseResponse write(@RequestBody FileDTO dto) {
		BaseResponse response = new BaseResponse(true);
		log.info("write api called");
		try {
			
			FileOutputStream fout = new FileOutputStream(dto.getPath() + "//" + dto.getName());
			byte[] b = dto.getData().getBytes();
			fout.write(b);
			fout.close();
		

			response.addMessage("successfully Update the data..");
			response.addResult(dto.getName(), dto.getData());
		} catch (Exception e) {
			e.printStackTrace();
			response.addMessage(e.toString());
			response.setSuccess(false);
			return response;
		}

		return response;

	}

	private String getData(String name, FileDTO dto) throws IOException {
		String data = "";
		FileInputStream fin = new FileInputStream(dto.getPath() + "//" + name);
		int i = 0;
		while ((i = fin.read()) != -1) {
			data += (char) i;
		}

		fin.close();
		return data;
	}

	private void fileIteration(String[] names, FileDTO dto) throws IOException {
		String data = "";
		log.info("clear the map<file,data> data.");
		filename_data.clear();
		for (String name : names) {
			data = getData(name,dto);
			filename_data.put(name, data);
		}

	}
	
	
}
